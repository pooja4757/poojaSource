export const environment = {
  production: true,
  ApiUrl : 'http://localhost:60025/api/'
};
