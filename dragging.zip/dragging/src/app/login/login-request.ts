export class LoginRequest {
    username: string;
    password: string

}

 export interface IAuthenticationDto
{
    userGuid: string
    firstName: string
    lastName: string
    username: string
    accessToken: string
    expiresAt: string
    issuedDate: string
    role : string
}
