import { Injectable } from '@angular/core';
import { environment } from "../../environments/environment.prod";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoginRequest, IAuthenticationDto } from './login-request';
import * as  moment from "moment"
import { CookieService } from 'ngx-cookie-service';


export const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',

  })
};

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  AuthUser: IAuthenticationDto;
  constructor(private httpClient: HttpClient, private cookie: CookieService   ) {
  }

  login(login: LoginRequest): Observable<any> {
    return this.httpClient.post<Observable<any>>(environment.ApiUrl + 'user/login', login, httpOptions).pipe();
  }

  public setSession(AuthUser: IAuthenticationDto, rememberMe: boolean) {
    this.AuthUser = AuthUser;
    if (rememberMe) {
      localStorage.setItem('access_token', AuthUser.accessToken);
      localStorage.setItem("expires_at", JSON.stringify(AuthUser.expiresAt.valueOf()));
      localStorage.setItem('first_name', AuthUser.firstName);
      localStorage.setItem('last_name', AuthUser.lastName);
      localStorage.setItem('user_name', AuthUser.username);
    }
    else {
     this.cookie.set('access_token', AuthUser.accessToken);
     this.cookie.set("expires_at", JSON.stringify(AuthUser.expiresAt.valueOf()));
     this.cookie.set('first_name', AuthUser.firstName);
     this.cookie.set('last_name', AuthUser.lastName);
     this.cookie.set('user_name', AuthUser.username)
    }
  }

  public isLoggedIn(): Boolean {
    const currentDate = moment();
    const expireAt = this.getExpiration();

    const a = moment(expireAt).isBefore(currentDate);

    // if there is no expiration of the token registered or if it has expired, return false
    if (!expireAt || moment(expireAt).isBefore(currentDate)) {
      return false;
    }

    if (this.AuthUser) {
      return true;
    }
    else {
      this.AuthUser = <IAuthenticationDto>{};
      console.log(this.cookie.check("first_name"))
      this.AuthUser.firstName = this.cookie.check("first_name") ?   this.cookie.get("first_name") : localStorage.getItem("first_name") ;
      this.AuthUser.lastName = this.cookie.check("last_name") ?   this.cookie.get("last_name") : localStorage.getItem("last_name")
      this.AuthUser.accessToken =this.cookie.check("access_token") ? this.cookie.get("access_token") :  localStorage.getItem("access_token")


      if (this.AuthUser.firstName && this.AuthUser.lastName) {
        return true
      }

      return false;
    }
  }

  public isLoggedOut(): Boolean {
    return !this.isLoggedIn();
  }

  public logout(): void {
    localStorage.removeItem("access_token");
    localStorage.removeItem("expires_at");
    localStorage.removeItem("first_name");
    localStorage.removeItem("last_name");
    localStorage.removeItem('user_name')
    this.AuthUser = null;
    this.cookie.deleteAll();
  }

  public getAccessToken(): string {
    return this.AuthUser ? this.AuthUser.accessToken : '';
  }

  public getExpiration(): moment.Moment {
    const expiration = localStorage.getItem("expires_at");
    const expiresAt = JSON.parse(expiration);
    return moment(expiresAt);
  }

}
