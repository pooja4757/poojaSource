import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { AuthService } from './auth.service';
import { LoginRequest, IAuthenticationDto } from './login-request';
import { ToastrService } from '../../../node_modules/ngx-toastr';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  loginRequest: LoginRequest;
  authenticationDto: IAuthenticationDto
  constructor(private authService: AuthService, private toaster: ToastrService, private router: Router) { }

  ngOnInit() {

    this.loginForm = new FormGroup(
      {
        'username': new FormControl('', Validators.required),
        'password': new FormControl('', [Validators.required, Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$#!%*?&])[A-Za-z\\d@$#!%*?&]{8,15}$')]),
        'rememberMe': new FormControl('')
      })
  }

  get username() { return this.loginForm.get('username'); }

  get password() { return this.loginForm.get('password'); }

  get rememberMe() { return this.loginForm.get('rememberMe'); }


  get loginValue() {
    return this.loginForm.value;

  }


  onSubmit() {
    this.loginRequest = new LoginRequest();
    this.loginRequest.username = this.username.value;
    this.loginRequest.password = this.password.value;
    this.authService.login(this.loginRequest).subscribe(
      d => {
        if (d == null) {
          this.toaster.error("User Name or  password Incorrect")
        }
        else {
          console.log(this.rememberMe)
          this.authenticationDto = d;
          this.authService.setSession(this.authenticationDto,this.rememberMe.value);
          this.router.navigate(['/home'])
        }
      }
    )
  }
}
