import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { moveItemInArray } from '@angular/cdk/drag-drop';
import { Requestmodel } from '../requestmodel';

@Component({
  selector: 'app-subrequest',
  templateUrl: './subrequest.component.html',
  styleUrls: ['./subrequest.component.css']
})
export class SubrequestComponent implements OnInit {

  @Input('SubRequestType') SubRequestType: Requestmodel;
  @Input('id') id: string;
  @Input('parentIds') parentIds: string;
  @Output('RequestObj') RequestObject = new EventEmitter<Requestmodel>();
  isShow: boolean = false
  constructor() { }

  ngOnInit() {
  }


  opendiv() {
    if (this.isShow) {
      this.isShow = false;
    }
    else
      this.isShow = true;
  }
  drop(event) {

    moveItemInArray(this.SubRequestType.Children, event.previousIndex, event.currentIndex);
    let sortH = event.currentIndex > event.previousIndex ? event.currentIndex : event.previousIndex;
    let sortL = event.currentIndex > event.previousIndex ? event.previousIndex : event.currentIndex
    for (let i = sortL; i <= sortH; i++) {
      this.SubRequestType.Children[i].SortOrder = i;
    }

    let data = JSON.parse(localStorage.getItem('Node'))
    this.updateNode(data, this.SubRequestType)
   console.log(data)

  }



  updateNode(data, new_size) {
 
    data.map(d => {
      if (d['RequestName'] === this.id) {
        d['Children'] = this.SubRequestType.Children
      }
      else {
        if (d['Children'].length > 0) {
          this.updateNode(d['Children'], this.SubRequestType.Children)
        }
      }
    })
    localStorage.removeItem('Node')
    localStorage.setItem('Node', JSON.stringify(data))
    console.log(data)
  }

}
