import { Component, OnInit, QueryList, ViewChildren, ChangeDetectorRef } from '@angular/core';
import { CdkDragDrop,
  CdkDropList,
  moveItemInArray,
  transferArrayItem,
  DropListRef,
  DragDrop
} from '@angular/cdk/drag-drop';


import { JsonPipe } from '@angular/common';
import { strictEqual } from 'assert';
import { Requestmodel, ConstRequestModel } from '../requestmodel';
@Component({
  selector: 'app-node',
  templateUrl: './node.component.html',
  styleUrls: ['./node.component.css']
})

 
export class NodeComponent {
  sortOrder:string[]=[];
  newArr:string[]=[];
  newTreeCatId:string[]=[];
  newTreeSortId:string[]=[];
    nodeE:Requestmodel[]=ConstRequestModel

   
     @ViewChildren(CdkDropList)
    childLists: QueryList<CdkDropList>;

   childListArr = [];

  constructor(private cdRef: ChangeDetectorRef) {
  
  }

 ngAfterViewInit() {
     console.log(this.childLists, this.childLists.toArray());
   this.childListArr =  this.childLists.toArray();
   this.cdRef.detectChanges();
  } 

  ngOnInit() {
    //this.droplistREf=this.dragDrop.createDropList(this.nodeE);
    //TO INVOKE DROP FUNCTIONALITY OF DRAGABLE COMPOENET INSIDE LIST
     

  //  this.nodeE.push(this.ne1);
    //this.nodeE.push(this.ne2);
   
  }

  OnSubmit() {

      //var SADF=this.resultOnSubmit;
  }

  drop(event: CdkDragDrop<string[]>) {
    /*  console.log('log', event);*/
    if (event.previousContainer === event.container) {
     
       moveItemInArray(
        event.container.data,
        event.previousIndex,
        event.currentIndex,
      ); 
      this.sortOrder.push(event.container.data[0]);
      this.sortOrder.push(event.container.data[1]);
      console.log(event.previousIndex," new -"+event.currentIndex)
      
      
         //(containerData[i] as object) as NodesDet;
        //$('*[data-id="'+asdf.id+'"]')[0]
        // $('*[data-id="'+containerData[i].id+'"]')[0]
      }
      debugger;
     event.currentIndex=event.previousIndex;
      //var containerData=event.container.data.toString();
      
    //  this.GetTreeData(containerData);
       for (let i = 0; i < event.container.data.length; i++) {
        var data=(event.container.data[i]);
        const nodeData = JSON.parse(JSON.stringify(data)) as Requestmodel;
        let selId=nodeData.id;
       let selOrder= this.nodeE.map(x=> x.id==selId);
       if(!selOrder)
       {
       }
       // var data = containerData[i](x => value.includes(x.GroupId));
        //var tempId= this.nodeE.findIndex((a: NodesDet)=>a.id==changedData.id);
        
       // this.nodeE[i].sortOrder=i;
       }
        //containerData[i].sortOrder=i;
       // var asdf=  JSON.parse(containerData[i]) as NodesDet;
        //console.log('asdf' +asdf);   */


    /*   if(event.container.data.length>0){
        for (let i = 0; i < event.container.data.length; i++) {
          console.log ("Block statement execution no." + i);
          
        }
       
      }
      
      
      console.log('index '+ this.index1 );
      this.nodeE[this.index1].sortOrder=event.currentIndex+1;
      console.log('Sort Order '+ this.nodeE[this.index1].sortOrder );
      
      //this.nodeE.map */
   
    
   
    /* console.log(event.container.data,
      event.previousIndex,
      event.currentIndex) */
  }

  GetTreeData(data:any)  {
     
  }
}


