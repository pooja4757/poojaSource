import { Requestmodel } from './requestmodel';

describe('Requestmodel', () => {
  it('should create an instance', () => {
    expect(new Requestmodel()).toBeTruthy();
  });
});
