export class Requestmodel {

    id: number;
    RequestName: string;
    SortOrder: number;
    Children: Requestmodel[];
}

export const ConstRequestModel: Requestmodel[] =
    [
        {
            id: 1,
            RequestName: 'R1',
            SortOrder: 0,
            Children: [
                {
                    id: 2, RequestName: 'sub1', SortOrder: 1,
                    Children: [{ id: 3, RequestName: 'subsub1', SortOrder: 0, Children: [] },
                    {
                        id: 3, RequestName: 'subsub2', SortOrder: 1, Children: [{
                            id: 3, RequestName: 'subsubsub1', SortOrder: 1,
                            Children: [
                                { id: 3, RequestName: 'subsubsubsub1', SortOrder: 0, Children: [] },
                                {
                                    id: 3, RequestName: 'subsubsubsub2', SortOrder: 1, Children: [
                                        { id: 3, RequestName: 'subsubsubsubsub1', SortOrder: 0, Children: [] },
                                        {
                                            id: 3, RequestName: 'subsubsubsubsub2', SortOrder: 1,
                                            Children: [
                                                { id: 3, RequestName: 'subsubsubsubsubsub1', SortOrder: 0, Children: [] },
                                                { id: 3, RequestName: 'subsubsubsubsubsub2', SortOrder: 1, Children: [] }
                                            ]
                                        }]
                                }
                            ]
                        }]

                    }]
                }]
        },
        {
            id: 2,
            RequestName: 'R2',
            SortOrder: 1,
            Children: [
                {
                    id: 2, RequestName: 'c1', SortOrder: 1,
                    Children: [{ id: 3, RequestName: 'cc1', SortOrder: 1, Children: [] }
                    ]
                }]

        },
        {
            id: 3,
            RequestName: 'R3',
            SortOrder: 2,
            Children: [
                {
                    id: 2, RequestName: 'c1', SortOrder: 1,
                    Children: [{ id: 3, RequestName: 'cc1', SortOrder: 1, Children: [] }
                    ]
                }]

        },
        {
            id: 4,
            RequestName: 'R4',
            SortOrder: 3,
            Children: [
                {
                    id: 2, RequestName: 'c1', SortOrder: 1,
                    Children: [{ id: 3, RequestName: 'cc1', SortOrder: 1, Children: [] }
                    ]
                }]

        },
        {
            id: 5,
            RequestName: 'R5',
            SortOrder: 4,
            Children: [
                {
                    id: 2, RequestName: 'c1', SortOrder: 1,
                    Children: [{ id: 3, RequestName: 'cc1', SortOrder: 1, Children: [] }
                    ]
                }]

        }


    ]
