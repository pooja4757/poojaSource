import { Component, OnInit } from '@angular/core';
import { DatePipe } from '../../../node_modules/@angular/common';
import { AppointmentRequest, IAppointmentDto } from './appointment';
import { AppointmentService } from './appointment.service';
import { ToastrService } from '../../../node_modules/ngx-toastr';
import { CookieService } from '../../../node_modules/ngx-cookie-service';
import *  as moment from 'Moment'


export class MeetingDate {
  meetingDate: number
  meetingFullDate: string
  Day: string;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [DatePipe]
})
export class HomeComponent implements OnInit {
  selected: { startDate: any, endDate: any };
  filterText : string;
  meetings: MeetingDate[] = [];
  numberOfDays: number = 90;
  appointmentRequest: AppointmentRequest
  appointmentDto: IAppointmentDto[] = [];
  IsdateShow: boolean = true;
  constructor(private cookie: CookieService, private datepipe: DatePipe, private appointmentService: AppointmentService, private toaster: ToastrService) { }

  ngOnInit() {


    this.calculateDate();
    this.getTodaysMeetings()

  }

  calculateDate() {
    let sDate = new Date();


    for (let index = 0; index < this.numberOfDays; index++) {

      let eDate = new Date();
      eDate.setDate(eDate.getDate() + index)
      let meeting = new MeetingDate();

      meeting.meetingFullDate = this.datepipe.transform(eDate, 'dd-MM-yyyy')
      meeting.meetingDate = eDate.getDate();
      this.meetings.push(meeting)


    }
  }

  getTodaysMeetings() {
    this.appointmentRequest = new AppointmentRequest();

    this.appointmentRequest.userName = this.cookie.check('user_name') ? this.cookie.get('user_name') : localStorage.getItem('user_name');
    this.appointmentRequest.startDate = this.datepipe.transform(new Date(), 'dd-MM-yyyy')
    this.assignMeetingData()
  }

  OnClick(args: any) {
    this.appointmentRequest = new AppointmentRequest()
    this.appointmentRequest.userName = this.cookie.check('user_name') ? this.cookie.get('user_name') : localStorage.getItem('user_name');
    this.appointmentRequest.startDate = args;
    this.assignMeetingData()
  }


  OnClickFilter(args: any) {
    this.appointmentRequest = new AppointmentRequest()
    this.appointmentRequest.userName = this.cookie.check('user_name') ? this.cookie.get('user_name') : localStorage.getItem('user_name');
    this.appointmentRequest.startDate = args;
    this.appointmentRequest.endDate = args;
    this.assignMeetingData()
  }

  assignMeetingData() {
    console.log(this.selected)
    this.appointmentService.getAppointMent(this.appointmentRequest).subscribe(appoint => {
      this.appointmentDto = appoint;
      if (this.appointmentDto.length == 0) {
        this.toaster.error("No Meetings available ")
      }
      else {
        this.appointmentDto = appoint;
        console.log(this.appointmentDto)
      }
    })

  }


  onClickDateRange() {

    debugger
    if (this.selected.endDate === null) {
      this.toaster.error("please select DateRange")
    }
    else {
      this.IsdateShow = false
      this.appointmentRequest = new AppointmentRequest();
      this.appointmentRequest.startDate = this.datepipe.transform(this.selected.startDate._d, 'dd-MM-yyyy')
      this.appointmentRequest.endDate = this.datepipe.transform(this.selected.endDate._d, 'dd-MM-yyyy')
      this.appointmentRequest.userName = this.cookie.check('user_name') ? this.cookie.get('user_name') : localStorage.getItem('user_name');
      this.assignMeetingData()
    }

    
  }

  FilterByText(args)
    {
    
      
    }


}
