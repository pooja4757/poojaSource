import { Injectable } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';
import { environment } from '../../environments/environment.prod';
import { AppointmentRequest } from './appointment';
import { httpOptions } from '../login/auth.service';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {

  constructor(private httpClient : HttpClient) {

   }

   getAppointMent(appointmentRequest:AppointmentRequest ): Observable<any>
   {
       return this.httpClient.post<Observable<any>>(environment.ApiUrl + 'appointment/getMeetings', appointmentRequest,httpOptions).pipe()
   }
}
