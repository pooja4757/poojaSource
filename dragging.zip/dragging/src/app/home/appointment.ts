export class AppointmentRequest {

    userName : string;
    startDate : string;
    endDate : string;
}


export interface IAppointmentDto {

    meetingId : number;
    startTime : string;
    endTime : string;
    subject : string;
    title : string;
    attendy : string;
}