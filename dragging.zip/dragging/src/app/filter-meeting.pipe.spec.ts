import { FilterMeetingPipe } from './filter-meeting.pipe';

describe('FilterMeetingPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterMeetingPipe();
    expect(pipe).toBeTruthy();
  });
});
